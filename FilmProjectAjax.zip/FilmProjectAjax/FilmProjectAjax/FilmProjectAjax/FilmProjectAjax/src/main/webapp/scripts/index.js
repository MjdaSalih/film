// When the document is ready..

	

		// When any element with input tag is clicked
		// execute the following function

		$("#load-insert").click(function() {

			// Get object of element with loadHere id
			// And in it load the hello.jsp file!

			$("#insertFilm").load("insert.jsp");
			$("#insertFilm").toggle("insert.jsp");

		});

		$("#load-update").click(function() {
			// Get object of element with loadHere id
			// And in it load the hello.jsp file!
			$("#updateFilm").load("update.jsp");
			$("#updateFilm").toggle("update.jsp");

		});

		$("#load-delete").click(function() {
			// Get object of element with loadHere id
			// And in it load the hello.jsp file!
			$("#deleteFilm").load("delete.jsp");
			$("#deleteFilm").toggle("delete.jsp");

		});

		$("#load-getFilm").click(function() {
			// Get object of element with loadHere id
			
			$("#getFilm").load("getFilm.jsp");
			$("#getFilm").toggle("getFilm.jsp");

		});
	
