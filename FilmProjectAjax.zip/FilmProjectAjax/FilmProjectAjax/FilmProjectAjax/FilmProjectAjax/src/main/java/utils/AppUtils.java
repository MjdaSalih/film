package utils;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.google.gson.Gson;

import model.Film;
import model.FilmList;

public class AppUtils {

	public String formatToXml(ArrayList<Film> allFilms) {
		// create JAXB context and instantiate marshaller
		FilmList filmlist = new FilmList();
		filmlist.setFilmList(allFilms);

		StringWriter sw = new StringWriter();

		JAXBContext context;
		try {
			context = JAXBContext.newInstance(FilmList.class);
			Marshaller m = context.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			m.marshal(filmlist, sw);
		} catch (JAXBException e) {
			e.printStackTrace();
		}
		return sw.toString();
	}
	
	

	public String formatToJSON(ArrayList<Film> allFilms) {

		Gson gson = new Gson();
		return gson.toJson(allFilms);

	}

	public String formatToString(ArrayList<Film> allFilms) {

		return allFilms.toString();

	}
	
	public String formatToXml2(ArrayList<Film> film) {
		// create JAXB context and instantiate marshaller
		
		ArrayList<Film> films = new ArrayList<Film>();
		films.addAll(film);
		FilmList filmlist = new FilmList();
		filmlist.setFilmList(films);

		StringWriter sw = new StringWriter();

		JAXBContext context;
		try {
			context = JAXBContext.newInstance(FilmList.class);
			Marshaller m = context.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			m.marshal(filmlist, sw);
		} catch (JAXBException e) {
			e.printStackTrace();
		}
		return sw.toString();
	}

	public String formatToJSON2(ArrayList<Film> filmList) {

		Gson gson = new Gson();
		return gson.toJson(filmList);

	}

	public String formatToString2(ArrayList<Film> filmList) {

		return filmList.toString();

	}

	

	

}
