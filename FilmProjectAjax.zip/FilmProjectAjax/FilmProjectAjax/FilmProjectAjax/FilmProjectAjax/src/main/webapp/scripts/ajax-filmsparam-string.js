function makeParamString(format) {
  var paramString =
    "&format=" + format;
  return(paramString);
}