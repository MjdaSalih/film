function getFilmTable(rows) {
  var headings = 
    [ "Film ID", "Title", "Year", "Stars", "Director", "Review" ];
  return(getTable(headings, rows));
}

function xmlFilmTable(resultRegion) {
  var address = "getAllFilms";
  var data = makeParamString("xml");
document.write(data);
  ajaxPost(address, data, 
           function(request) { 
             showXmlFilmInfo(request, resultRegion); 
           });
}


		

function showXmlFilmInfo(request, resultRegion) {
  if ((request.readyState == 4) &&
      (request.status == 200)) {
    var xmlDocument = request.responseXML;
    var films = 
      xmlDocument.getElementsByTagName("film");
    var rows = new Array();
    for(var i=0; i<films.length; i++) {
      var film = films[i];
      var subElements = 
        ["id", "title", "year", "stars", "director", "review"];
      rows[i] = getElementValues(film, subElements);
    }
    var table = getFilmTable(rows);
    htmlInsert(resultRegion, table);
  }
}

function jsonFilmTable(resultRegion, field1, field2) {
  var address = "getAllFilms";
  var data = makeParamString(field1, field2, "json");
  ajaxPost(address, data, 
           function(request) { 
             showJsonFilmInfo(request, resultRegion); 
           });
}

function showJsonFilmInfo(request, resultRegion) {
  if ((request.readyState == 4) &&
      (request.status == 200)) {
    var rawData = request.responseText;
    var films = eval("(" + rawData + ")");
    var rows = new Array();
    for(var i=0; i<films.length; i++) {
      var film = films[i];
      rows[i] = [film.id, film.firstName,
                 film.lastName, film.balance];
    }
    var table = getFilmTable(rows);
    htmlInsert(resultRegion, table);
  }
}

function stringFilmTable(resultRegion, field1, field2) {
  var address = "getAllFilms";
  var data = makeParamString(field1, field2, "string");
  ajaxPost(address, data, 
           function(request) { 
             showStringFilmInfo(request, resultRegion); 
           });
}

function showStringFilmInfo(request, resultRegion) {
  if ((request.readyState == 4) &&
      (request.status == 200)) {
    var rawData = request.responseText;
    var films = rawData.split(/\n+/);
    var rows = new Array();
    for(var i=0; i<films.length; i++) {
      if (films[i].length > 1) {  // Ignore blank lines
        rows.push(films[i].split("#"));
      }
    }
    var table = getFilmTable(rows);
    htmlInsert(resultRegion, table);
  }
}