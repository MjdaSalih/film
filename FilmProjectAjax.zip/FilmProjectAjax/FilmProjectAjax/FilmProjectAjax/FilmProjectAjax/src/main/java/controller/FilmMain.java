package controller;

import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import db.FilmDAO;
import model.Film;


public class FilmMain {


    public static void main(String[] args) throws SQLException { 
    	

		FilmDAO film = new FilmDAO();
		
		
		Film f = new Film(11402, "Spiderman 8", 2000, "Star wars", "Star wars", "Star wars");

			System.out.println(film.updateFilm(f));
    }
}