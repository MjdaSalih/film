package controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.google.gson.Gson;

import db.FilmDAO;
import model.Film;
import model.FilmList;
import utils.AppUtils;

/**
 * Servlet implementation class getFilm
 */


public class getAllFilms extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

		AppUtils utils = new AppUtils();

		FilmDAO film = new FilmDAO();
		ArrayList<Film> filmList = film.getAllFilms();

		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Pragma", "no-cache");
		

		String format = request.getParameter("format");
		String outputPage;
		System.out.println(format);
		if ("xml".equals(format)) {
			response.setContentType("text/xml");
			outputPage = "/WEB-INF/results/film-xml.jsp";

			String xmlData = utils.formatToXml(filmList);
			
			request.setAttribute("data", xmlData);
			RequestDispatcher dispatcher = request.getRequestDispatcher(outputPage);
			dispatcher.include(request, response);

		} else if ("json".equals(format)) {
			response.setContentType("application/json");
			outputPage = "/WEB-INF/results/film-json.jsp";

			String jsonData = utils.formatToJSON(filmList);
			
			request.setAttribute("data", jsonData);
			RequestDispatcher dispatcher = request.getRequestDispatcher(outputPage);
			dispatcher.include(request, response);
			
		} else {
		      response.setContentType("text/plain");
		      outputPage = "/WEB-INF/results/film-string.jsp";
		      
		      String stringData = utils.formatToString(filmList);
		      
		      request.setAttribute("data", stringData);
				RequestDispatcher dispatcher = request.getRequestDispatcher(outputPage);
				dispatcher.include(request, response);

		}
	}

	
	
	


	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}