package db;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Film;

import java.sql.*;


public class FilmDAO {
	
	Film oneFilm = null;
	
	
	
	Connection conn = null;
    Statement stmt = null;
	String user = "salihmjd";
    String password = "Uclefask3";
    // Note none default port used, 6306 not 3306
    String url = "jdbc:mysql://mudfoot.doc.stu.mmu.ac.uk:6306/"+user;

	public FilmDAO() {}

	
	private void openConnection(){
		// loading jdbc driver for mysql
		try{
		    Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch(Exception e) { System.out.println(e); }

		// connecting to database
		try{
			// connection string for demos database, username demos, password demos
 			conn = DriverManager.getConnection(url, user, password);
		    stmt = conn.createStatement();
		} catch(SQLException se) { System.out.println(se); }	   
    }
	private void closeConnection(){
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private Film getNextFilm(ResultSet rs){
    	Film thisFilm=null;
		try {
			thisFilm = new Film(
					rs.getInt("id"),
					rs.getString("title"),
					rs.getInt("year"),
					rs.getString("director"),
					rs.getString("stars"),
					rs.getString("review"));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return thisFilm;		
	}
	
	
	
   public ArrayList<Film> getAllFilms(){
	   
		ArrayList<Film> allFilms = new ArrayList<Film>();
		openConnection();
		
	    // Create select statement and execute it
		try{
		    String selectSQL = "select * from films";
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
	    // Retrieve the results
		    while(rs1.next()){
		    	oneFilm = getNextFilm(rs1);
		    	allFilms.add(oneFilm);
		   }

		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }

	   return allFilms;
   }
   
   public List<Film> get_films(){
		openConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		List<Film> list=new ArrayList<Film>();
		try {
			String querry="select * from films ";
			ps=conn.prepareStatement(querry);
			rs=ps.executeQuery();
			while(rs.next()){
				Film obj_Film_Bean=new Film();
				obj_Film_Bean.setTitle(rs.getString("title"));
				obj_Film_Bean.setYear(rs.getInt("year"));
				obj_Film_Bean.setDirector(rs.getString("director"));
				obj_Film_Bean.setStars(rs.getString("stars"));
				obj_Film_Bean.setReview(rs.getString("review"));
				list.add(obj_Film_Bean);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return list;
	}

   public Film getFilmByID(int id){
	   
		openConnection();
		oneFilm=null;
	    // Create select statement and execute it
		try{
		    String selectSQL = "select * from films where id="+id;
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
	    // Retrieve the results
		    while(rs1.next()){
		    	oneFilm = getNextFilm(rs1);
		    }

		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }

	   return oneFilm;
   }

	public ArrayList<Film> getFilmByName(String title) {
		ArrayList<Film> oneFilm2 = new ArrayList<Film>();
		openConnection();

		int filmtitlefound = 0;

		// Create select statement and execute it
		try {
			String selectSQL = "select * from films where title Like'" + title + "%'";
			ResultSet rs1 = stmt.executeQuery(selectSQL);
			// Retrieve the results
			while (rs1.next()) {
				oneFilm = getNextFilm(rs1);
				oneFilm2.add(oneFilm);

			}
			for (int i = 0; i < oneFilm2.size(); i++) {

				filmtitlefound++;

			}

			if (filmtitlefound < 1) {

				System.out.println("Film Title Does not exist");

			} else {

				System.out.println(filmtitlefound + " Films Found!");

			}

			stmt.close();
			closeConnection();
		} catch (SQLException se) {
			System.out.println(se);
		}

		return oneFilm2;
	}
   
	
   
	public String deleteFilm(int id) {
		openConnection();
		String sql = "DELETE FROM films where id ='" + id + "'";

		try (

				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return "1 Film deleted";
	}


	public boolean insertFilm2(Film f) {

		openConnection();
		String SQL = "INSERT INTO films (title,year,director,stars,review) VALUES(?,?,?,?,?)";

		

		try (PreparedStatement pstmt = conn.prepareStatement(SQL, Statement.RETURN_GENERATED_KEYS)) {

			//pstmt.setInt(1, f.getId());
			pstmt.setString(1, f.getTitle());
			pstmt.setInt(2, f.getYear());
			pstmt.setString(3, f.getDirector());
			pstmt.setString(4, f.getStars());
			pstmt.setString(5, f.getReview());

			int affectedRows = pstmt.executeUpdate();
			// check the affected rows
			if (affectedRows > 0) 
				return true;
			
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return false;
	}
	
	public String updateFilm(Film f) throws SQLException {

		openConnection();

		String SQL = "UPDATE films SET title = ? , year = ? , director = ? , stars = ? , review = ? WHERE id = ?";

		try {
			// create our java preparedstatement using a sql update query
			PreparedStatement ps = conn.prepareStatement(SQL);

			// set the preparedstatement parameters

			ps.setString(1, f.getTitle());
			ps.setInt(2, f.getYear());
			ps.setString(3, f.getDirector());
			ps.setString(4, f.getStars());
			ps.setString(5, f.getReview());
			ps.setInt(6, f.getId());

			// call executeUpdate to execute our sql update statement
			ps.executeUpdate();
			ps.close();
		} catch (SQLException se) {
			// log the exception
			throw se;
		}
		return "1 film has been updated";
	}
	
	


}

