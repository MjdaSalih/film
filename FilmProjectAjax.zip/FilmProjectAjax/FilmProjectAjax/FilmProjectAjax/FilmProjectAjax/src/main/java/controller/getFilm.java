package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db.FilmDAO;
import model.Film;
import utils.AppUtils;

/**
 * Servlet implementation class getFilm
 */
@WebServlet("/getFilm")
public class getFilm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getFilm() {
        super();
        
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

    	   AppUtils utils = new AppUtils();

           FilmDAO film = new FilmDAO();

           response.setHeader("Cache-Control", "no-cache");
           response.setHeader("Pragma", "no-cache");

           String format = request.getParameter("format");
           String title = request.getParameter("title");
           String outputPage;
           System.out.println(format);
           System.out.println(title);
           if ("xml".equals(format)) {
               response.setContentType("text/xml");
               outputPage = "/WEB-INF/results/film-xml.jsp";

               String xmlData = utils.formatToXml2(film.getFilmByName(title));

               request.setAttribute("data", xmlData);
               RequestDispatcher dispatcher = request.getRequestDispatcher(outputPage);
               
               dispatcher.include(request, response);
               
           } else if ("json".equals(format)) {
   			response.setContentType("application/json");
   			outputPage = "/WEB-INF/results/film-json.jsp";

   			String jsonData = utils.formatToJSON2(film.getFilmByName(title));
   			
   			request.setAttribute("data", jsonData);
   			RequestDispatcher dispatcher = request.getRequestDispatcher(outputPage);
   			dispatcher.include(request, response);
   			
   		} else if ("string".equals(format)){
   		      response.setContentType("text/plain");
   		      outputPage = "/WEB-INF/results/film-string.jsp";
   		      
   		      String stringData = utils.formatToString2(film.getFilmByName(title));
   		      
   		      request.setAttribute("data", stringData);
   				RequestDispatcher dispatcher = request.getRequestDispatcher(outputPage);
   				dispatcher.include(request, response);

           }
           
          
       }
    

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("getFilm.jsp");
		dispatcher.forward(request, response);

		
		
		
	}

}
